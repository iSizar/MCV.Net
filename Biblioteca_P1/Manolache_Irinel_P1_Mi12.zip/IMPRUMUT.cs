namespace Biblioteca_P1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("IMPRUMUT")]
    public partial class IMPRUMUT
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public IMPRUMUT()
        {
            REVIEW = new HashSet<REVIEW>();
        }

        public int ImprumutId { get; set; }

        public int? CarteId { get; set; }

        public int? CititorId { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DataImprumut { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DataScadenta { get; set; }

        [Column(TypeName = "date")]
        public DateTime? DataRestituire { get; set; }

        public virtual CARTE CARTE { get; set; }

        public virtual CITITOR CITITOR { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<REVIEW> REVIEW { get; set; }
    }
}
