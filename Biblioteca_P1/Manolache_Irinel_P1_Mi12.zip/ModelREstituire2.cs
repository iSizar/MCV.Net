namespace Biblioteca_P1
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ModelREstituire2 : DbContext
    {
        public ModelREstituire2()
            : base("name=ModelREstituire2")
        {
        }

        public virtual DbSet<CARTE> CARTsE { get; set; }
        public virtual DbSet<CITITOR> CITITORs { get; set; }
        public virtual DbSet<IMPRUMUT> IMPRUMUTs { get; set; }
        public virtual DbSet<REVIEW> REVIEWs { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CARTE>()
                .Property(e => e.Titlu)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CITITOR>()
                .Property(e => e.Nume)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CITITOR>()
                .Property(e => e.Prenume)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CITITOR>()
                .Property(e => e.Adresa)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CITITOR>()
                .Property(e => e.Email)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CITITOR>()
                .Property(e => e.Stare)
                .IsFixedLength();

            modelBuilder.Entity<REVIEW>()
                .Property(e => e.Text)
                .IsUnicode(false);
        }
    }
}
