namespace Biblioteca_P1
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ModelCumarareCarti : DbContext
    {
        public ModelCumarareCarti()
            : base("name=ModelCumarareCarti")
        {
        }

        public virtual DbSet<AUTOR> AUTORs { get; set; }
        public virtual DbSet<CARTE> CARTEs { get; set; }
        public virtual DbSet<GEN> GENs { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AUTOR>()
                .Property(e => e.Nume)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<AUTOR>()
                .Property(e => e.Prenume)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CARTE>()
                .Property(e => e.Titlu)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<GEN>()
                .Property(e => e.Descriere)
                .IsFixedLength()
                .IsUnicode(false);
        }
    }
}
