﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Biblioteca_P1
{
    public class Program
    {
        
        static void Main(string[] args)
        {
            menager m = new menager();
            
            GEN g1 = m.getGEN("SF");

            AUTOR a1 = m.getAutor(nume: "Andrei", prenume: "Tudor");

            CARTE c1 = m.getCarte(titlu: "Flori de Cosmos",autor: a1, gen: g1);
           
            //int nr_carti = 3;
            /*---------------------------------------------------------*/
            //metoda 1 exemplu de folosire
            AchizitionareCarti ac = new AchizitionareCarti();
            //ac.achizitioneazaCarte(c1, nr_carti);


            /*---------------------------------------------------------*/
            //metoda 2 expemul de folosire
            //ImprumutaCarte ic = new ImprumutaCarte();
            CITITOR cititor1 = m.getCititor(nume: "Dragan", prenume: "Silviu", adresa: "Iasi,Iasi,Str. Codrescu nr.13,cammin C12", email: "silviuaka.dragan@uaic.ro");
            //ic.imprumutaCarte(cititor1, gen: "SF");

            /*---------------------------------------------------------*/
            //metoda 3 ex de folosire
            //RestituieCartea(c1, cititor1,"O carte foarte relaxanta.");
            //Restituire r = new Restituire();
            //r.RestituieCartea(c1, cititor1, "O carte foarte relaxanta");


            DateTime d1 = DateTime.Now.AddDays(-10);
            DateTime d2 = DateTime.Now;
            Statistica s = new Statistica();
            //s.ReaderBetweenDates(d1,d2);
            //s.getMostFaimousAutors();
            //s.getMostComuneGens();
            //s.MostWantedBooks();
            
        }
        
    }
    
}
