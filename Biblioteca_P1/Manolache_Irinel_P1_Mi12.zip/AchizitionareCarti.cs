﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca_P1
{
    public class AchizitionareCarti
    {
        public void achizitioneazaCarte(CARTE carte,int nr_carti)
        {
            using (var context = new ModelCumarareCarti())
            {
                    //verificam daca un autorul cartii exista in bd
                    Boolean foud = false;
                    var items = context.AUTORs;
                    foreach (var autor in items)
                    {
                        if (autor.Nume.Equals(carte.AUTOR.Nume) && autor.Prenume.Equals(carte.AUTOR.Prenume))
                        {
                            foud = true;
                        }
                    }
                    if (!foud) // daca autorul nu a fost gasit il introducem in baza de date
                    {
                        context.AUTORs.Add(carte.AUTOR);
                    }

                    //verificam daca genul cartii exista in baza de date
                    var items2 = context.GENs;
                    foreach (var gen in items2)
                    {
                        if (gen.Descriere.Equals(carte.GEN.Descriere))
                        {
                            foud = true;
                        }
                    }
                    if (!foud) // daca genul nu a fost gasit il introducem in baza de date
                    {
                        context.GENs.Add(carte.GEN);
                    }

                    //adaugam cartile in baza de date
                    for (int j = 0; j< nr_carti; ++j)
                    {
                        CARTE c = new CARTE()
                        {
                            AUTOR = carte.AUTOR,
                            GEN = carte.GEN,
                            Titlu = carte.Titlu

                        };
                        context.CARTEs.Add(c);
                    }
                    context.SaveChanges();
                    
               }
        }

       

    }
}
