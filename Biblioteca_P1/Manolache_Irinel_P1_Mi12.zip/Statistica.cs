﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca_P1
{
    public class Statistica
    {
        public List<CITITOR> ReaderBetweenDates(DateTime d1, DateTime d2)
        {
            List<CITITOR> list = new List<CITITOR>();
            using (var context = new ModelGeneral())
            {


                var citiori = context.CITITORs.Where(x => x.IMPRUMUTs.Where(y => (y.DataImprumut >= d1 && y.DataImprumut <= d2) || (y.DataRestituire >= d1 && y.DataRestituire <= d2)).Count() != 0);
                Console.WriteLine("Numarul de cititori activi: {0}", citiori.Count());
                Console.WriteLine("Cititorii activi di aceasta perioada sunt:");
                foreach (var cititor in citiori)
                {
                    Console.WriteLine("Nume: {0}, Prenume: {1}, email: {2}, adresa: {3}", cititor.Nume, cititor.Prenume, cititor.Email, cititor.Adresa);
                    list.Add(cititor);
                }



            }
            return list;

        }

        public List<CARTE> MostWantedBooks()
        {//Cele mai solicitate carti.
            List<CARTE> list = new List<CARTE>();
            using (var context = new ModelGeneral())
            {
                int nr_taken = 0;
                foreach(var carte in context.CARTEs)
                {
                    int nr_exemp_date = context.IMPRUMUTs.Where(x => x.CARTE.Titlu.Trim().Equals(carte.Titlu.Trim()) &&
                    (x.CARTE.AUTOR.Nume.Trim().Equals(carte.AUTOR.Nume) && x.CARTE.AUTOR.Prenume.Trim().Equals(carte.AUTOR.Prenume))).Count();

                    if (nr_exemp_date > nr_taken)
                        nr_taken = nr_exemp_date;
                    
                }

                foreach (var carte in context.CARTEs)
                {
                    int nr_exemp_date = context.IMPRUMUTs.Where(x => x.CARTE.Titlu.Trim().Equals(carte.Titlu.Trim()) &&
                    (x.CARTE.AUTOR.Nume.Trim().Equals(carte.AUTOR.Nume) && x.CARTE.AUTOR.Prenume.Trim().Equals(carte.AUTOR.Prenume))).Count();

                    if (nr_exemp_date == nr_taken)
                    {
                        Console.WriteLine("Cartea: {0} scrisa de: {1} {2}", carte.Titlu, carte.AUTOR.Prenume, carte.AUTOR.Nume);
                        list.Add(carte);
                    }
                }
            }
            return list;
        }

        public List<AUTOR> getMostFaimousAutors()
        {
            List<AUTOR> list = new List<AUTOR>();
            using (var context = new ModelGeneral())
            {
                int nr_taken = 0;
                foreach (var autor in context.AUTORs)
                {
                    int nr_exemp_date = context.IMPRUMUTs.Where(x=>
                    x.CARTE.AUTOR.Nume.Trim().Equals(autor.Nume) && x.CARTE.AUTOR.Prenume.Trim().Equals(autor.Prenume)).Count();

                    if (nr_exemp_date > nr_taken)
                        nr_taken = nr_exemp_date;

                }

                foreach (var autor in context.AUTORs)
                {
                    int nr_exemp_date = context.IMPRUMUTs.Where(x =>
                    x.CARTE.AUTOR.Nume.Trim().Equals(autor.Nume) && x.CARTE.AUTOR.Prenume.Trim().Equals(autor.Prenume)).Count();

                    if (nr_exemp_date == nr_taken)
                    {
                        Console.WriteLine("{0} {1}", autor.Prenume, autor.Nume);
                        list.Add(autor);
                    }
                }
            }
            return list;
        }

        public List<GEN> getMostComuneGens()
        {//Genurile cele mai solicitate
            List<GEN> lista = new List<GEN>();
            using (var context = new ModelGeneral())
            {
                int nr_taken = 0;
                foreach (var gen in context.GENs)
                {
                    int nr_exemp_date = context.IMPRUMUTs.Where(x =>
                        x.CARTE.GEN.Descriere.Trim().Equals(gen.Descriere)).Count();

                    if (nr_exemp_date > nr_taken)
                        nr_taken = nr_exemp_date;

                }

                foreach (var gen in context.GENs)
                {
                    int nr_exemp_date = context.IMPRUMUTs.Where(x =>
                        x.CARTE.GEN.Descriere.Trim().Equals(gen.Descriere)).Count();

                    if (nr_exemp_date == nr_taken) {
                        Console.WriteLine("{0}", gen.Descriere);
                        lista.Add(gen);
                    }
                }
            }
            return lista;
        }

        public List<string> getReviews(CARTE Carte)
        {
            List<string> list = new List<string>();
            using(var context = new ModelGeneral())
            {
                foreach(var rev in context.REVIEWs)
                {
                    if ((rev.IMPRUMUT.CARTE.Titlu.Trim().Equals(Carte.Titlu.Trim()) && rev.IMPRUMUT.CARTE.AUTOR.Nume.Trim().Equals(Carte.AUTOR.Nume.Trim())
                        && rev.IMPRUMUT.CARTE.AUTOR.Prenume.Trim().Equals(Carte.AUTOR.Prenume.Trim())))
                            
                        list.Add(rev.Text);
                }
            }
            return list;
        }

        
    }
}
