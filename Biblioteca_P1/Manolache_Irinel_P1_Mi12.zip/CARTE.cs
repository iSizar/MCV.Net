namespace Biblioteca_P1
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CARTE")]
    public partial class CARTE
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public CARTE()
        {
            IMPRUMUT = new HashSet<IMPRUMUT>();
        }

        public int CarteId { get; set; }

        public int? AutorId { get; set; }

        [StringLength(50)]
        public string Titlu { get; set; }

        public int? GenId { get; set; }

        public virtual AUTOR AUTOR { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<IMPRUMUT> IMPRUMUT { get; set; }

        public virtual GEN GEN { get; set; }
    }
}
