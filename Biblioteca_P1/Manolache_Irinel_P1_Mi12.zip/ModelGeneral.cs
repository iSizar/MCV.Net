namespace Biblioteca_P1
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class ModelGeneral : DbContext
    {
        public ModelGeneral()
            : base("name=ModelGeneral")
        {
        }

        public virtual DbSet<AUTOR> AUTORs { get; set; }
        public virtual DbSet<CARTE> CARTEs { get; set; }
        public virtual DbSet<CITITOR> CITITORs { get; set; }
        public virtual DbSet<GEN> GENs { get; set; }
        public virtual DbSet<IMPRUMUT> IMPRUMUTs { get; set; }
        public virtual DbSet<REVIEW> REVIEWs { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AUTOR>()
                .Property(e => e.Nume)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<AUTOR>()
                .Property(e => e.Prenume)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CARTE>()
                .Property(e => e.Titlu)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CITITOR>()
                .Property(e => e.Nume)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CITITOR>()
                .Property(e => e.Prenume)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CITITOR>()
                .Property(e => e.Adresa)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CITITOR>()
                .Property(e => e.Email)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<CITITOR>()
                .Property(e => e.Stare)
                .IsFixedLength();

            modelBuilder.Entity<GEN>()
                .Property(e => e.Descriere)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<REVIEW>()
                .Property(e => e.Text)
                .IsUnicode(false);
        }
    }
}
