﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca_P1
{
    public class Restituire
    {
        // a 3-a metoda
        public string RestituieCartea(CARTE book, CITITOR cititor, string rewiew)
        {
            string return_msg = "defoult";
            using (var context = new ModelGeneral())
            {
                Console.WriteLine("{0}", book.Titlu);
                bool found = false;
                foreach (IMPRUMUT imp in context.IMPRUMUTs)
                {

                    if( ((imp.CARTE.Titlu.Trim().Equals(book.Titlu.Trim()) && imp.CITITOR.Nume.Trim().Equals(cititor.Nume.Trim()))&& imp.CITITOR.Prenume.Trim().Equals(cititor.Prenume.Trim()))
                            && !imp.DataRestituire.HasValue)
                        {
                        found = true;
                        imp.DataRestituire = DateTime.Now;
                        REVIEW rew = new REVIEW()
                        {
                            IMPRUMUT = imp,
                            Text = rewiew
                        };
                        int nr_intarzieri = context.IMPRUMUTs.Where(x => x.CititorId == imp.CititorId && x.DataRestituire > x.DataScadenta).Count();
                        if (nr_intarzieri >= 2)
                        {
                            context.CITITORs.Add(imp.CITITOR);
                            context.Entry(imp.CITITOR).State = System.Data.Entity.EntityState.Modified;
                        }
                        
                        context.REVIEWs.Add(rew);
                    }
                }
                if (!found)
                {
                    return_msg = "Cartea nu a fost imprumutata de la biblioteca aceasta sau a fost restituita.";
   
                }
                else
                {
                    return_msg =  "Restituirea a fost cu succes.";
                   
                }
                context.SaveChanges();
            }
            return return_msg;
        }
    }
}
