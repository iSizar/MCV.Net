﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca_P1
{
    public class ImprumutaCarte
    {
        public bool cautaCititor(CITITOR cititor, ICollection<CITITOR> cititori)
        {
            bool foud = false;
            foreach (var reader in cititori)
            {
                if (reader.Nume.Equals(cititor.Nume) && reader.Prenume.Equals(cititor.Prenume))
                {
                    if (reader.Adresa.Equals(cititor.Adresa) && reader.Email.Equals(cititor.Email))
                    {//afisez starea cititorului
                        foud = true;
                        Console.WriteLine("Starea cititorului este: {0}", reader.Stare);
                    }
                }
            }
            return foud;
        }

        public bool verificaDisponibila(CARTE carte, List<IMPRUMUT> lista)
        {
            bool found = false;
            foreach (var imp in lista)
            {
                if (imp.CarteId == carte.CarteId)
                {
                    found = true;
                    if (imp.DataRestituire.HasValue)
                        return true;
                }
            }
            if (found)
            {
                return false;
            }
            return true;
        }

        public DateTime searchDataScadenta(CARTE carte, ICollection<IMPRUMUT> imprumuturi)
        {
            foreach (var imp in imprumuturi)
            {
                if (imp.CarteId == carte.CarteId)
                {
                    return (DateTime)imp.DataScadenta;
                }
            }
            return DateTime.Now;//nu va ajunge niciodata aici! deoarece daca nu s-a imprumutat cartea si avem o
                                // carte in lista de carti filtrate  => sigur exista un imprumut pentru cartea aceea


        }
        
        // a 2-a metoda
        public string imprumutaCarte(CITITOR cititor, string gen,string carte_titlu,string nume_a,string prenume_a)
        {
            string ret_str = "";
            using (var context = new ModelGeneral())
            {
                //cauta cititorul
                bool foud = cautaCititor(cititor, context.CITITORs.ToList());

                if (!foud)
                {//adaug cititorul
                    context.CITITORs.Add(cititor);
                }

                //caut si afisez cartile de genul cerut
                Console.WriteLine("Cartea care au genul cautat sunt:");
                ICollection<CARTE> carti = new List<CARTE>();
                foreach (var carte in context.CARTEs)
                {
                    if (carte.GEN.Descriere.Trim().Equals(gen))
                    {
                        carti.Add(carte);
                        Console.WriteLine("{0} de {1},", carte.Titlu, carte.AUTOR.Prenume + carte.AUTOR.Nume);

                    }
                }
                //caut cartile dupa autor si sau titlu
                string titlu = carte_titlu.Trim();
                string autor_nume = nume_a.Trim();
                string autor_prenume = prenume_a.Trim();


                bool cititor_Satisfacut = false;
                ICollection<CARTE> carti_filtrate = new List<CARTE>();
                if (titlu.Trim().Equals("") && autor_nume.Trim().Equals(""))
                {
                    Console.WriteLine("Argumente insuficiente pentru imprumout");
                    ret_str = "Argumente insuficiente pentru imprumout";
                    return ret_str;
                }
                else
                {
                    if (titlu.Trim().Equals("") && !autor_nume.Trim().Equals(""))
                    {//fac cautare dupa autor
                        foreach (var carte in carti)
                        {
                            if (carte.AUTOR.Nume.Trim().Equals(autor_nume) && carte.AUTOR.Prenume.Trim().Equals(autor_prenume))
                            {
                                carti_filtrate.Add(carte);
                                foud = verificaDisponibila(carte, context.IMPRUMUTs.ToList());
                                if (foud)
                                {
                                    cititor_Satisfacut = true;
                                    IMPRUMUT imp = new IMPRUMUT()
                                    {
                                        CARTE = carte,
                                        DataImprumut = DateTime.Now,
                                        DataScadenta = DateTime.Now.AddDays(14),
                                        CITITOR = cititor
                                    };
                                    context.IMPRUMUTs.Add(imp);
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (!titlu.Equals("") && autor_nume.Equals(""))
                        {//fac cautare dupa titlu
                            foreach (var carte in carti)
                            {
                                if (carte.Titlu.Trim().Equals(titlu))
                                {
                                    carti_filtrate.Add(carte);
                                    foud = verificaDisponibila(carte, context.IMPRUMUTs.ToList());
                                    if (foud)
                                    {
                                        cititor_Satisfacut = true;
                                        IMPRUMUT imp = new IMPRUMUT()
                                        {
                                            CARTE = carte,
                                            DataImprumut = DateTime.Now,
                                            DataScadenta = DateTime.Now.AddDays(14),
                                            CITITOR = cititor
                                        };
                                        context.IMPRUMUTs.Add(imp);
                                        break;
                                    }

                                }
                            }

                        }
                        else
                        {//fac cautare dupa ambele
                            foreach (var carte in carti)
                            {
                                if ((carte.Titlu.Trim().Equals(titlu)) && (carte.AUTOR.Nume.Trim().Equals(autor_nume) && carte.AUTOR.Prenume.Trim().Equals(autor_prenume)))
                                {
                                    carti_filtrate.Add(carte);
                                    foud = verificaDisponibila(carte, context.IMPRUMUTs.ToList());
                                    if (foud)
                                    {
                                        cititor_Satisfacut = true;
                                        IMPRUMUT imp = new IMPRUMUT()
                                        {
                                            CARTE = carte,
                                            DataImprumut = DateTime.Now,
                                            DataScadenta = DateTime.Now.AddDays(14),
                                            CITITOR = cititor
                                        };
                                        context.IMPRUMUTs.Add(imp);
                                        break;
                                    }
                                }
                            }
                        }
                    }

                }

                if (carti_filtrate.Count() == 0)
                {
                    Console.WriteLine("Cartea cautata nu exista...");
                    ret_str = "Cartea cautata nu exista...";
                    return ret_str;
                }
                if (!cititor_Satisfacut)
                {//caut cea mai apropiata data la care cartea cautata este disponibila
                    var imprumuturi = context.IMPRUMUTs.ToList();
                    DateTime d_min = searchDataScadenta(carti_filtrate.ElementAt(0), imprumuturi);
                    foreach (var carte in carti_filtrate)
                    {
                        var data = searchDataScadenta(carti_filtrate.ElementAt(0), imprumuturi);
                        if (d_min > data)
                        {
                            d_min = data;
                        }
                    }
                    Console.WriteLine("data la care cartea cautata va fi disponibila este: {0}", d_min.ToString());
                    ret_str = "data la care cartea cautata va fi disponibila este:" + d_min.ToString();
                    return ret_str;
                }
                
                context.SaveChanges();
                return "Carte imprumutata cu succes";
            }
        }
    }
}
